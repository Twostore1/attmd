// Buat Lu Yang Jual Sc Ini Yang Jujur Jangan Samp Nipu Apalagi Lari Dari Tanggung Jawab



const fs = require('fs')
const chalk = require('chalk')

global.gr = 'https://chat.whatsapp.com/JzXpGWhy6FT0B3evbjYiA9'
global.ig = '@sanz_offc1' // ubah aja
global.email = 'sanzoffc@gmail.com' //serah
global.region = 'indonesia' // serah
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'SanZ OFFCIAL⚡🗿' //ubah jadi nama mu, note tanda ' gausah di hapus!
global.domain = 'https://azizxofficial.thomvelz.my.id' // Isi Domain Lu
global.apikey2 = 'ptla_d95d3Ci3OtObEgnOFAgtLD7lWVU6qrxfBA3NBqOLZbf' // Isi Apikey Plta Lu
global.capikey2 = 'ptlc_iBAT1oOakGR01blVYGH5xXXKOygk4cxTGZSqwwhnNuE' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
//=================================================//
global.owner = ['6287818371699'] // ubah aja pake nomor lu
//==========================BY Hw Mods=======================//
global.keyopenai = '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'
//====================BY Hw Mods=============================//
global.botname = 'BOTZ -SanZ⚡🗿' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'SanZOffc⚡🗿' // ubah aja ini nama sticker
global.author = '@SanZofficiañ⚡🗿' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'haikal' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.anticall = true
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})